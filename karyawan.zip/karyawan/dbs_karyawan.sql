-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 26 Jun 2020 pada 09.36
-- Versi server: 10.4.6-MariaDB
-- Versi PHP: 7.1.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbs_karyawan`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `absensi_karyawan`
--

CREATE TABLE `absensi_karyawan` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `absen` int(11) NOT NULL,
  `hadir` int(11) NOT NULL,
  `tidak_hadir` int(11) NOT NULL,
  `izin` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `absensi_karyawan`
--

INSERT INTO `absensi_karyawan` (`id`, `nama`, `absen`, `hadir`, `tidak_hadir`, `izin`) VALUES
(1, 'Muhammad Julfansa', 1, 1, 0, 1),
(2, 'wira', 0, 0, 0, 1),
(3, 'erika sri wahyuni', 0, 0, 0, 5),
(4, 'H. Eko Prabowo A.P,M.Si', 0, 0, 0, 2),
(5, 'H. Eko Prabowo A.P,M.Si', 0, 0, 0, 0),
(6, 'Wirahadi Basyiri', 0, 0, 0, 0),
(7, 'H. Eko Prabowo A.P,M.Si', 0, 0, 0, 0),
(8, 'Pahmi', 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `alasan_karyawan`
--

CREATE TABLE `alasan_karyawan` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `alasan` varchar(255) NOT NULL,
  `tanggal` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `alasan_karyawan`
--

INSERT INTO `alasan_karyawan` (`id`, `nama`, `alasan`, `tanggal`) VALUES
(1, 'Muhammad Julfansa', 'Izin cuti mengikuti seminar di jakarta.', '08/04/2019'),
(2, 'wira', 'mengantar anak', '24/06/2020'),
(3, 'erika sri wahyuni', 'rapat dinas', '24/06/2020'),
(4, 'H. Eko Prabowo A.P,M.Si', 'Rapat dinas', '24/06/2020'),
(5, 'Erika Sri Wahyuni', 'check up ke rumah sakit', '25/06/2020');

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_karyawan`
--

CREATE TABLE `data_karyawan` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `age` int(11) NOT NULL,
  `start_date` varchar(255) NOT NULL,
  `salary` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `handphone` varchar(255) NOT NULL,
  `nik` varchar(255) NOT NULL,
  `tentang` varchar(255) NOT NULL,
  `image_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `data_karyawan`
--

INSERT INTO `data_karyawan` (`id`, `name`, `position`, `age`, `start_date`, `salary`, `email`, `handphone`, `nik`, `tentang`, `image_name`) VALUES
(3, 'Erika Sri Wahyuni', 'Kasubag Umum', 38, '26/05/2007', 7000000, 'erikasriwahyuni18@gmail.com', '082198735254', '43562635546766', 'pegawai yang tegas dan disiplin', 'IMG-20200620-WA00901.jpg'),
(7, 'H. Eko Prabowo A.P,M.Si', 'Kepala Dinas', 46, '01/01/1995', 10000000, 'ekoprabowo@gmail.com', '082134567859', '32445798956314445', 'Kepala Dinas Perhubungan Kota Bogor yang tegas dan disiplin', 'images_jpeg1.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `history_karyawan`
--

CREATE TABLE `history_karyawan` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `info` varchar(255) NOT NULL,
  `tanggal` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `history_karyawan`
--

INSERT INTO `history_karyawan` (`id`, `nama`, `info`, `tanggal`) VALUES
(1, 'Admin', 'Admin telah melakukan login', '08/04/2019 11:03:54'),
(2, 'Admin', 'Admin telah melakukan login', '08/04/2019 11:04:22'),
(3, 'Muhammad Julfansa', 'Muhammad Julfansa Telah melakukan login', '08/04/2019 11:07:42'),
(4, 'Muhammad Julfansa', 'Muhammad Julfansa telah melakukan absen', '08/04/2019 11:08:05'),
(5, 'Muhammad Julfansa', 'Muhammad Julfansa Telah melakukan login', '08/04/2019 11:08:05'),
(6, 'Muhammad Julfansa', 'Muhammad Julfansa Telah melakukan login', '08/04/2019 11:08:29'),
(7, 'Admin', 'Admin telah melakukan login', '08/04/2019 11:08:43'),
(8, 'Muhammad Julfansa', 'Muhammad Julfansa Telah melakukan login', '08/04/2019 11:09:28'),
(9, 'Admin', 'Admin telah melakukan login', '24/06/2020 12:17:20'),
(10, 'Admin', 'Admin telah melakukan login', '24/06/2020 12:17:56'),
(11, 'Admin', 'Admin telah melakukan login', '24/06/2020 12:19:02'),
(12, 'Admin', 'Admin telah melakukan login', '24/06/2020 12:20:24'),
(13, 'Admin', 'Admin telah melakukan login', '24/06/2020 12:22:44'),
(14, 'Admin', 'Admin telah melakukan login', '24/06/2020 12:23:48'),
(15, 'Admin', 'Admin telah melakukan login', '24/06/2020 12:24:47'),
(16, 'Admin', 'Admin telah melakukan login', '24/06/2020 12:25:45'),
(17, 'Admin', 'Admin telah melakukan login', '24/06/2020 12:25:47'),
(18, 'Admin', 'Admin telah melakukan login', '24/06/2020 12:26:00'),
(19, 'Admin', 'Admin telah melakukan login', '24/06/2020 13:05:53'),
(20, 'Admin', 'Admin telah melakukan login', '24/06/2020 13:06:11'),
(21, 'Admin', 'Admin telah melakukan login', '24/06/2020 13:06:53'),
(22, 'Admin', 'Admin telah melakukan login', '24/06/2020 13:08:50'),
(23, 'Admin', 'Admin telah melakukan login', '24/06/2020 13:10:50'),
(24, 'Admin', 'Admin telah melakukan login', '24/06/2020 13:11:05'),
(25, 'Admin', 'Admin telah melakukan login', '24/06/2020 13:13:52'),
(26, 'Admin', 'Admin telah melakukan login', '24/06/2020 13:24:17'),
(27, 'Admin', 'Admin telah melakukan login', '24/06/2020 13:30:27'),
(28, 'Admin', 'Admin telah melakukan login', '24/06/2020 13:32:04'),
(29, 'Admin', 'Admin telah melakukan login', '24/06/2020 14:55:27'),
(30, 'Admin', 'Admin telah melakukan login', '24/06/2020 15:11:27'),
(31, 'Admin', 'Admin telah melakukan login', '24/06/2020 15:12:56'),
(32, 'Admin', 'Admin telah melakukan login', '24/06/2020 15:13:16'),
(33, 'Admin', 'Admin telah melakukan login', '24/06/2020 15:33:42'),
(34, 'Admin', 'Admin telah melakukan login', '24/06/2020 15:53:23'),
(35, 'Admin', 'Admin telah melakukan login', '24/06/2020 19:44:51'),
(36, 'Admin', 'Admin telah melakukan login', '24/06/2020 19:59:33'),
(37, 'Admin', 'Admin telah melakukan login', '24/06/2020 20:40:51'),
(38, 'Admin', 'Admin telah melakukan login', '24/06/2020 23:08:36'),
(39, 'Admin', 'Admin telah melakukan login', '25/06/2020 06:42:00'),
(40, 'Admin', 'Admin telah melakukan login', '25/06/2020 13:30:56'),
(41, 'Admin', 'Admin telah melakukan login', '25/06/2020 17:24:05'),
(42, 'Admin', 'Admin telah melakukan login', '26/06/2020 13:03:39'),
(43, 'Admin', 'Admin telah melakukan login', '26/06/2020 13:05:09'),
(44, 'Admin', 'Admin telah melakukan login', '26/06/2020 13:05:10'),
(45, 'Admin', 'Admin telah melakukan login', '26/06/2020 13:05:30'),
(46, 'Admin', 'Admin telah melakukan login', '26/06/2020 13:05:31'),
(47, 'Admin', 'Admin telah melakukan login', '26/06/2020 13:06:54');

-- --------------------------------------------------------

--
-- Struktur dari tabel `setting_absensi`
--

CREATE TABLE `setting_absensi` (
  `id` int(11) NOT NULL,
  `mulai_absen` varchar(255) NOT NULL,
  `selesai_absen` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `setting_absensi`
--

INSERT INTO `setting_absensi` (`id`, `mulai_absen`, `selesai_absen`) VALUES
(1, '07:00', '07:45');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users_karyawan`
--

CREATE TABLE `users_karyawan` (
  `id` int(11) NOT NULL,
  `nik` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `level` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `users_karyawan`
--

INSERT INTO `users_karyawan` (`id`, `nik`, `password`, `level`) VALUES
(1, '332', '8b6bc5d8046c8466359d3ac43ce362ab', 'Admin'),
(2, '778899', '55587a910882016321201e6ebbc9f595', 'Karyawan'),
(3, '37465746519846', '6215f4770ee800ad5402bc02be783c26', 'Karyawan'),
(4, '43562635546766', '79b50d4df1dde87477f9b7c94811b969', 'Karyawan'),
(5, '35478464535635', '7aff54a8405dfa34685f7b6749eb603b', 'Karyawan'),
(6, '33764745782399', '7aff54a8405dfa34685f7b6749eb603b', 'Karyawan'),
(7, '341434459612446', '6215f4770ee800ad5402bc02be783c26', 'Karyawan'),
(8, '32445798956314445', '7aff54a8405dfa34685f7b6749eb603b', 'Karyawan'),
(9, '4265872567846592', 'b7ec53b0af39d69485aace162fb3af05', 'Karyawan');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `absensi_karyawan`
--
ALTER TABLE `absensi_karyawan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `alasan_karyawan`
--
ALTER TABLE `alasan_karyawan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `data_karyawan`
--
ALTER TABLE `data_karyawan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `history_karyawan`
--
ALTER TABLE `history_karyawan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `setting_absensi`
--
ALTER TABLE `setting_absensi`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `users_karyawan`
--
ALTER TABLE `users_karyawan`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `absensi_karyawan`
--
ALTER TABLE `absensi_karyawan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `alasan_karyawan`
--
ALTER TABLE `alasan_karyawan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `data_karyawan`
--
ALTER TABLE `data_karyawan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `history_karyawan`
--
ALTER TABLE `history_karyawan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT untuk tabel `setting_absensi`
--
ALTER TABLE `setting_absensi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `users_karyawan`
--
ALTER TABLE `users_karyawan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
